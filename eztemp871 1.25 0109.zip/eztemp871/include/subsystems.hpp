#pragma once

#include "api.h"
#include "lift.hpp"

// Your motors, sensors, etc. should go here.  Below are examples

inline pros::Motor lb(-19);
inline pros::MotorGroup liftMotors({-19});
inline lib::Lift lift(&liftMotors, 1, {2, 0, 7});
inline pros::Motor intake(-20);
inline pros::adi::DigitalOut mogo('H');
inline pros::adi::DigitalOut doink('G');

// inline pros::Motor intake(1);
// inline pros::adi::DigitalIn limit_switch('A');